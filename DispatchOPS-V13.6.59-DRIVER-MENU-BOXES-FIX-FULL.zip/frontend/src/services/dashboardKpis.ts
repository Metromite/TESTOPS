/**
 * services/dashboardKpis.ts
 * ---------------------------
 * SUPABASE PORT of the old FastAPI backend's `services/dashboard_kpis.py`
 * (Home tab only - see that file's own module docstring for why the other
 * dashboard tabs, e.g. Lead Time, Order Summary, Area Analytics, were
 * never in scope for this file even in the OLD version). Every function
 * below is a line-for-line port of its Python counterpart, kept under the
 * SAME function name (translated to camelCase) specifically so this file
 * can be diffed against dashboard_kpis.py to verify nothing was
 * reinterpreted along the way.
 *
 * ARCHITECTURE NOTE: the old backend did `db.query(...).filter(...)` (SQL)
 * for the cheap, static parts (date range, single-driver match) and then
 * almost everything else - Global Filters, Dashboard Configuration
 * exclusions, driver/area/vehicle authoritative-list restriction, all KPI
 * arithmetic, chart bucketing - in plain Python over the already-fetched
 * rows. This port keeps that same split: a narrow Supabase query for the
 * date range (the one thing worth pushing to the database), then the rest
 * in TypeScript over the returned rows, in the same order the Python
 * did it, computing the same numbers.
 *
 * PERFORMANCE NOTE: like the original, this pulls every matching
 * sap_invoice_facts / landmark_visit_facts row across the wire before
 * computing anything - there is no server-side aggregation. That was true
 * of the old backend too (it just did the same fetch-then-aggregate one
 * network hop closer to the database). For a dataset that's grown large
 * enough for this to matter, the fix is a Postgres materialized view or
 * RPC that pre-aggregates - deliberately not attempted here, since doing
 * that correctly needs the same care and real-data verification as the
 * rest of this port, not a rewrite bolted on top of an already-large
 * change.
 */
import { supabase, getFederatedSupabaseClients } from "@/lib/supabase";
import { getCached, setCached } from "../hooks/dashboardCache";
import { dashboardFilterParams } from "../types/dashboardFilters";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface FilterParams {
  driver: string;
  drivers: string; // comma-separated
  areas: string;
  division: string;
  route_type: string;
  vehicle_type: string;
  facility_type: string;
  salesman: string;
  start_date: string;
  end_date: string;
}

interface SapRow {
  invoice_no: string;
  invoice_date: string | null;
  dispatch_date: string | null;
  driver_name: string;
  helper_name: string;
  vehicle_num: string;
  vehicle_key: string;
  vehicle_type: string;
  customer_name: string;
  area: string;
  division_desc: string;
  facility_type: string;
  salesman: string;
  boxes: number;
  normal_boxes: number;
  freezer_boxes: number;
  not_supplied_reason: string;
  [key: string]: unknown;
}

interface LandmarkRow {
  vehicle_key: string;
  customer_name: string;
  arrival: string;
  departure: string;
  is_passthrough: boolean;
  is_depot: boolean;
}

interface ConfigRule {
  rule_type: string;
  value: string;
  operator: string; // contains|starts_with|ends_with|exact|regex
  negate: boolean;
  logic: string; // AND|OR
}

interface AreaRow {
  name: string;
  sector: string;
  route_type: string;
  vehicle_type: string;
}

export interface Kpis {
  valid_invoices: number;
  total_boxes: number;
  freezer_boxes: number;
  normal_boxes: number;
  active_drivers: number;
  avg_boxes_per_driver: number;
  not_supplied: number;
  avg_lead_time_days: number | null;
  unique_customers: number;
  avg_route_hours: number | null;
  orders_per_driver: number;
  active_vehicles: number;
}
export interface DriverRow {
  driver_name: string;
  vehicle_num: string;
  vehicle_type: string;
  orders: number;
  boxes: number;
  freezer: number;
  not_supplied: number;
}
export interface Charts {
  driver_boxes: { labels: string[]; values: number[] };
  facility: { labels: string[]; values: number[] };
  vantype: { labels: string[]; normal: number[]; freezer: number[] };
  returns: { delivered: number; not_supplied: number };
}
export interface HomeDashboard {
  kpis: Kpis;
  driver_overview: DriverRow[];
  charts: Charts;
}
export interface HomeDetailResponse {
  metric: string;
  columns: string[];
  rows: Record<string, unknown>[];
  truncated: boolean;
  total_matching: number;
}

type HomeRpcCacheEntry = { value?: HomeDashboard; promise?: Promise<HomeDashboard>; expires: number };
const homeRpcCache = new Map<string, HomeRpcCacheEntry>();
const HOME_RPC_CACHE_MS = 30_000;

function homeFilterJson(f: FilterParams): Record<string, unknown> {
  const list = (v: string) => String(v || "").split(",").map(x => x.trim()).filter(Boolean);
  return {
    driver: f.driver || "", drivers: list(f.drivers), areas: list(f.areas), division: list(f.division),
    route_type: [], vehicle_type: list(f.vehicle_type), facility_type: list(f.facility_type),
    salesman: list(f.salesman), lead_time_band: "", classification: "",
  };
}

function homeRpcKey(f: FilterParams): string {
  return JSON.stringify([f.start_date,f.end_date,f.driver,f.drivers,f.areas,f.division,f.vehicle_type,f.facility_type,f.salesman]);
}

function mergeHomeSnapshots(parts: any[]): HomeDashboard {
  const num = (v: unknown) => Number(v || 0);
  const driverMap = new Map<string, any>();
  for (const p of parts) for (const r of (p?.driver_overview || [])) {
    const k = String(r.driver_name || "");
    if (!k) continue;
    const old = driverMap.get(k);
    if (!old) driverMap.set(k, { ...r });
    else { old.orders=num(old.orders)+num(r.orders); old.boxes=num(old.boxes)+num(r.boxes); old.freezer=num(old.freezer)+num(r.freezer); old.not_supplied=num(old.not_supplied)+num(r.not_supplied); if ((!old.vehicle_num || old.vehicle_num==='-') && r.vehicle_num) old.vehicle_num=r.vehicle_num; }
  }
  const drivers=[...driverMap.values()].sort((a,b)=>num(b.boxes)-num(a.boxes));
  const facilityMap=new Map<string,{value:number;labels:string[]}>();
  const vtMap=new Map<string,{normal:number;freezer:number;label:string}>();
  let valid=0,totalBoxes=0,freezer=0,normal=0,notSup=0,customers=0,activeVehicles=0;
  let leadWeighted=0,leadWeight=0,routeWeighted=0,routeWeight=0;
  for(const p of parts){
    const k=p?.kpis||{}; valid+=num(k.valid_invoices); totalBoxes+=num(k.total_boxes); freezer+=num(k.freezer_boxes); normal+=num(k.normal_boxes); notSup+=num(k.not_supplied); customers+=num(k.unique_customers); activeVehicles+=num(k.active_vehicles);
    if(k.avg_lead_time_days!==null&&k.avg_lead_time_days!==undefined){leadWeighted+=num(k.avg_lead_time_days)*num(k.valid_invoices); leadWeight+=num(k.valid_invoices);}
    if(k.avg_route_hours!==null&&k.avg_route_hours!==undefined){routeWeighted+=num(k.avg_route_hours); routeWeight+=1;}
    const fc=p?.charts?.facility; for(let i=0;i<(fc?.labels||[]).length;i++){const raw=String(fc.labels[i]||"").trim();if(!raw)continue;const label=normalizeDimension(raw);const existing=facilityMap.get(label)||{value:0,labels:[]};existing.value+=num(fc.values?.[i]);existing.labels.push(raw);facilityMap.set(label,existing);}
    const vc=p?.charts?.vantype; for(let i=0;i<(vc?.labels||[]).length;i++){const raw=String(vc.labels[i]||"").trim();const label=normalizeDimension(raw);const x=vtMap.get(label)||{normal:0,freezer:0,label:raw};x.normal+=num(vc.normal?.[i]);x.freezer+=num(vc.freezer?.[i]);if(raw && raw !== raw.toUpperCase() && x.label === x.label.toUpperCase()) x.label=raw;vtMap.set(label,x);}
  }
  const activeDrivers=drivers.length;
  const facilityKeys=[...facilityMap.keys()].sort(); const facilityLabels=facilityKeys.map(k=>canonicalLabel(facilityMap.get(k)?.labels||[k])); const vtKeys=[...vtMap.keys()].sort();
  const vtLabels=vtKeys.map(k=>vtMap.get(k)?.label || k);
  return {
    kpis:{valid_invoices:valid,total_boxes:totalBoxes,freezer_boxes:freezer,normal_boxes:normal,active_drivers:activeDrivers,avg_boxes_per_driver:activeDrivers?Math.round(totalBoxes/activeDrivers*10)/10:0,not_supplied:notSup,avg_lead_time_days:leadWeight?Math.round(leadWeighted/leadWeight*10)/10:null,unique_customers:customers,avg_route_hours:routeWeight?Math.round(routeWeighted/routeWeight*10)/10:null,orders_per_driver:activeDrivers?Math.round(valid/activeDrivers*10)/10:0,active_vehicles:activeVehicles},
    driver_overview:drivers,
    charts:{driver_boxes:{labels:drivers.map(r=>r.driver_name),values:drivers.map(r=>num(r.boxes))},facility:{labels:facilityLabels,values:facilityKeys.map(x=>facilityMap.get(x)?.value||0)},vantype:{labels:vtLabels,normal:vtKeys.map(x=>vtMap.get(x)?.normal||0),freezer:vtKeys.map(x=>vtMap.get(x)?.freezer||0)},returns:{delivered:valid-notSup,not_supplied:notSup}}
  };
}

function canonicalizeHomeSnapshotToFleet(snapshot: HomeDashboard, _fleetVehicles: Map<string, { number: string; type: string }>): HomeDashboard {
  const vt = snapshot.charts?.vantype;
  if (!vt) return snapshot;
  const grouped = new Map<string, { label: string; normal: number; freezer: number }>();
  for (let i = 0; i < (vt.labels || []).length; i++) {
    const raw = String(vt.labels[i] || "").trim();
    const key = normalizeDimension(raw).includes("pickup") ? "pickup" : "van";
    const cur = grouped.get(key) || { label: key === "pickup" ? "Pickup" : "Van", normal: 0, freezer: 0 };
    cur.normal += Number(vt.normal?.[i] || 0);
    cur.freezer += Number(vt.freezer?.[i] || 0);
    grouped.set(key, cur);
  }
  return { ...snapshot, charts: { ...snapshot.charts, vantype: {
    labels: ["Van", "Pickup"],
    normal: [grouped.get("van")?.normal || 0, grouped.get("pickup")?.normal || 0],
    freezer: [grouped.get("van")?.freezer || 0, grouped.get("pickup")?.freezer || 0],
  } } };
}

const DASHBOARD_RANGE_CACHE_KEY = "dispatchops-dashboard-latest-range-v3";
const FILTER_META_CACHE_PREFIX = "dispatchops-dashboard-filter-meta-v3:";
const DRIVER_OPTIONS_CACHE_PREFIX = "dispatchops-dashboard-driver-options-v3:";
const DRIVER_DIRECTORY_CACHE_KEY = "dispatchops-dashboard-driver-directory-v1";
const DASHBOARD_PRELOAD_VERSION = "v2";
const FILTER_META_CACHE_MS = 10 * 60_000;
const DRIVER_OPTIONS_CACHE_MS = 10 * 60_000;
let dashboardPreloadPromise: Promise<void> | null = null;
let dashboardPreloadKey = "";

function rangeCacheKey(startDate?: string, endDate?: string): string {
  return `${String(startDate || "")}::${String(endDate || "")}`;
}
function readJsonCache<T>(key: string, maxAgeMs: number): T | null {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || Date.now() - Number(parsed.savedAt || 0) > maxAgeMs) return null;
    return parsed.value as T;
  } catch { return null; }
}
function writeJsonCache(key: string, value: unknown): void {
  try { localStorage.setItem(key, JSON.stringify({ savedAt: Date.now(), value })); } catch {}
}

function hasMeaningfulFilterMeta(value: Partial<DashboardFilterMeta> | null | undefined): boolean {
  if (!value) return false;
  return [value.divisions, value.facility_types, value.salesmen, value.areas, value.drivers, value.vehicle_types, value.route_types]
    .some((v) => Array.isArray(v) && v.length > 0);
}

function hasMeaningfulDriverOptions(value: { drivers?: unknown[]; driver_names?: unknown[] } | null | undefined): boolean {
  return !!value && ((Array.isArray(value.drivers) && value.drivers.length > 0) || (Array.isArray(value.driver_names) && value.driver_names.length > 0));
}

function readLegacyFilterMetaCache(): DashboardFilterMeta | null {
  try {
    const raw = localStorage.getItem("dispatchops-dashboard-filter-meta-v6");
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return hasMeaningfulFilterMeta(parsed?.value) ? parsed.value as DashboardFilterMeta : null;
  } catch { return null; }
}
function dashboardFilterMetaCacheKey(startDate?: string, endDate?: string): string {
  return `${FILTER_META_CACHE_PREFIX}${rangeCacheKey(startDate, endDate)}`;
}
function dashboardDriverOptionsCacheKey(startDate?: string, endDate?: string, filters: Record<string, unknown> = {}): string {
  return `${DRIVER_OPTIONS_CACHE_PREFIX}${JSON.stringify([startDate || "", endDate || "", filters])}`;
}

function monthRangeFromDate(value: string) {
  const [year, month] = String(value || "").slice(0, 7).split("-").map(Number);
  if (!year || !month) return null;
  const lastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
  return {
    start: `${year}-${String(month).padStart(2, "0")}-01`,
    end: `${year}-${String(month).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`,
  };
}

export function getPreloadedDashboardRange(): { start: string; end: string } | null {
  try {
    const raw = localStorage.getItem(DASHBOARD_RANGE_CACHE_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    if (parsed?.start && parsed?.end) return { start: String(parsed.start), end: String(parsed.end) };
  } catch {}
  return null;
}

export function getCachedDashboardFilterMeta(startDate?: string, endDate?: string): DashboardFilterMeta | null {
  const exact = readJsonCache<DashboardFilterMeta>(dashboardFilterMetaCacheKey(startDate, endDate), FILTER_META_CACHE_MS);
  if (exact) return exact;
  return (!startDate && !endDate) ? readJsonCache<DashboardFilterMeta>(FILTER_META_CACHE_PREFIX + "default", FILTER_META_CACHE_MS) : null;
}

export function getCachedDashboardDriverOptions(
  startDate?: string,
  endDate?: string,
  filters: { areas?: string[]; division?: string[]; facility_type?: string[]; salesman?: string[]; vehicle_type?: string[] } = {},
): { drivers: string[]; driver_names: Array<{ code: string; name: string }> } | null {
  const payload = {
    areas: filters.areas || [], division: filters.division || [], facility_type: filters.facility_type || [],
    salesman: filters.salesman || [], vehicle_type: filters.vehicle_type || [],
  };
  return readJsonCache<{ drivers: string[]; driver_names: Array<{ code: string; name: string }> }>(
    dashboardDriverOptionsCacheKey(startDate, endDate, payload), DRIVER_OPTIONS_CACHE_MS,
  );
}

export function getCachedDashboardDriverDirectory(): Array<{ code: string; name: string }> {
  return readJsonCache<Array<{ code: string; name: string }>>(DRIVER_DIRECTORY_CACHE_KEY, 60 * 60_000) || [];
}

async function discoverLatestDashboardRange(): Promise<{ start: string; end: string } | null> {
  try {
    const results = await Promise.all(getFederatedSupabaseClients().map(async (client: any) => {
      try {
        const { data, error } = await client.from("sap_invoice_facts").select("dispatch_date").not("dispatch_date", "is", null).order("dispatch_date", { ascending: false }).limit(1);
        if (error) return null;
        return data?.[0]?.dispatch_date ? String(data[0].dispatch_date).slice(0, 10) : null;
      } catch { return null; }
    }));
    const latest = results.filter(Boolean).sort().pop();
    const range = latest ? monthRangeFromDate(String(latest)) : null;
    if (range) {
      try { localStorage.setItem(DASHBOARD_RANGE_CACHE_KEY, JSON.stringify({ savedAt: Date.now(), ...range })); } catch {}
    }
    return range;
  } catch { return null; }
}

async function preloadDashboardDriverDirectory(): Promise<void> {
  const existing = getCachedDashboardDriverDirectory();
  if (existing.length) return;
  try {
    const { data, error } = await supabase.from("drivers").select("code,name").order("name");
    if (!error && Array.isArray(data)) writeJsonCache(DRIVER_DIRECTORY_CACHE_KEY, data);
  } catch {}
}

/**
 * Starts the Dashboard interaction dataset before the user navigates to it.
 * The selected month/range is loaded once; slicer changes are then resolved in
 * browser memory rather than by issuing one RPC per tab/filter combination.
 */
export function preloadDashboardFastPath(): Promise<void> {
  const cachedRange = getPreloadedDashboardRange();
  const desiredKey = cachedRange ? `${cachedRange.start}:${cachedRange.end}:${DASHBOARD_PRELOAD_VERSION}` : "discovering";
  if (dashboardPreloadPromise && dashboardPreloadKey === desiredKey) return dashboardPreloadPromise;
  dashboardPreloadKey = desiredKey;
  dashboardPreloadPromise = (async () => {
    const range = getPreloadedDashboardRange() || await discoverLatestDashboardRange();
    if (!range) return;

    // One bounded dataset + one compact GPS/route aggregation is the new
    // interaction fast-path. All slicer changes after this point are local
    // filtering; we deliberately do NOT warm five separate tab RPCs because
    // that only moves the database work earlier without making clicks local.
    try {
      const { preloadDashboardLocalDataset } = await import("./dashboardLocalStore");
      await preloadDashboardLocalDataset("", "");
    } catch {}

    // Keep the small metadata caches warm for other Dashboard consumers and
    // for the first render while the local dataset is being prepared.
    await Promise.allSettled([
      getDashboardFilterMeta(range.start, range.end),
      preloadDashboardDriverDirectory(),
    ]);
  })().catch(() => {}).then(() => undefined);
  return dashboardPreloadPromise;
}

export async function fetchHomeDashboardRpc(f: FilterParams): Promise<HomeDashboard> {
  const key=homeRpcKey(f); const now=Date.now(); const hit=homeRpcCache.get(key);
  if(hit && hit.expires>now){if(hit.value)return hit.value;if(hit.promise)return hit.promise;}
  const promise=(async()=>{
    const { getFederatedSupabaseClients } = await import("@/lib/supabase");
    const filters=homeFilterJson(f);
    const parts=await Promise.all(getFederatedSupabaseClients().map(async(client:any)=>{
      const {data,error}=await client.rpc("dispatchops_dashboard_home_snapshot",{p_start:f.start_date||null,p_end:f.end_date||null,p_filters:filters});
      if(error) throw new Error(error.message); return data||{};
    }));
    const merged = mergeHomeSnapshots(parts);
    const fleetVehicles = await fetchFleetVehicleMap();
    return canonicalizeHomeSnapshotToFleet(merged, fleetVehicles);
  })();
  homeRpcCache.set(key,{promise,expires:now+60_000});
  try{const value=await promise;homeRpcCache.set(key,{value,expires:Date.now()+HOME_RPC_CACHE_MS});return value;}catch(e){homeRpcCache.delete(key);throw e;}
}

// ---------------------------------------------------------------------------
// Small helpers - direct ports of the Python module's private helpers
// ---------------------------------------------------------------------------

/** Direct port of normalize_vehicle() (services/identity_engine.py). */
function normalizeVehicle(v: string | null | undefined): string {
  if (!v) return "";
  return String(v).trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
}

/** Dashboard dimensions are data-driven, not fixed enums. Normalize only for
 * grouping/matching so VAN/Van/van remain one category while the displayed
 * label comes from the authoritative Fleet value when available. */
function normalizeDimension(v: unknown): string {
  return String(v ?? "").trim().toLowerCase().replace(/[^a-z0-9]+/g, "");
}

function canonicalLabel(values: string[]): string {
  return values.map(v => String(v || "").trim()).filter(Boolean).sort((a,b) => {
    const al = a.toLowerCase(), bl = b.toLowerCase();
    const aUpper = a === a.toUpperCase() && a !== a.toLowerCase();
    const bUpper = b === b.toUpperCase() && b !== b.toLowerCase();
    if (aUpper !== bUpper) return aUpper ? 1 : -1;
    return al.localeCompare(bl);
  })[0] || "";
}

const MONTHS: Record<string, number> = {
  JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6,
  JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12,
};

/** Direct port of _parse_arrival_datetime(). */
function parseArrivalDatetime(arrivalStr: string | null | undefined): Date | null {
  if (!arrivalStr) return null;
  const s = String(arrivalStr).trim();
  let y: number | null = null, mo: number | null = null, d: number | null = null;

  let m = s.match(/^(\d{1,2})\s+([A-Za-z]{3})\w*\s+(\d{4})/);
  if (m) {
    const mon = MONTHS[m[2].toUpperCase().slice(0, 3)];
    if (mon) { d = parseInt(m[1], 10); mo = mon; y = parseInt(m[3], 10); }
  }
  if (y === null) {
    m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if (m) { d = parseInt(m[1], 10); mo = parseInt(m[2], 10); y = parseInt(m[3], 10); }
  }
  if (y === null) {
    m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (m) { y = parseInt(m[1], 10); mo = parseInt(m[2], 10); d = parseInt(m[3], 10); }
  }
  if (y === null || mo === null || d === null) return null;

  const tm = s.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?\s*$/);
  const h = tm ? parseInt(tm[1], 10) : 0;
  const mi = tm ? parseInt(tm[2], 10) : 0;
  const se = tm && tm[3] ? parseInt(tm[3], 10) : 0;
  const dt = new Date(y, mo - 1, d, h, mi, se);
  return isNaN(dt.getTime()) ? null : dt;
}

/** Direct port of _is_depot_landmark() - the depot-detection keyword is a
 * literal piece of this company's business data (their own depot's name
 * in the Landmark GPS system), copied exactly, not a generic algorithm. */
function isDepotLandmark(customerName: string | null | undefined): boolean {
  const up = (customerName || "").toUpperCase();
  return up.includes("CITY PHARMACY") && up.includes("IND");
}

/** Direct port of _build_driver_perf(). */
function buildDriverPerf(sapRows: SapRow[]) {
  const driverMap = new Map<string, { driver_name: string; helper_name: string; vehicle_num: string; vehicle_key: string; vehicle_type: string; invoices: number; boxes: number; normal: number; freezer: number }>();
  for (const r of sapRows) {
    const name = r.driver_name || "Unknown";
    let d = driverMap.get(name);
    if (!d) {
      d = { driver_name: name, helper_name: r.helper_name, vehicle_num: r.vehicle_num, vehicle_key: r.vehicle_key, vehicle_type: r.vehicle_type, invoices: 0, boxes: 0, normal: 0, freezer: 0 };
      driverMap.set(name, d);
    }
    d.invoices += 1;
    d.boxes += r.boxes || 0;
    d.normal += r.normal_boxes || 0;
    d.freezer += r.freezer_boxes || 0;
  }
  return driverMap;
}

/** Direct port of _build_lm_route_map() - per-vehicle route start (depot
 * departure) to end (last delivery stop departure), for Avg Route Hours. */
function buildLmRouteMap(lmRows: LandmarkRow[]) {
  const byVehicle = new Map<string, LandmarkRow[]>();
  for (const r of lmRows) {
    if (!r.vehicle_key) continue;
    if (!byVehicle.has(r.vehicle_key)) byVehicle.set(r.vehicle_key, []);
    byVehicle.get(r.vehicle_key)!.push(r);
  }

  const routeMap = new Map<string, { route_duration_minutes: number; stops: number }>();
  for (const [vkey, rows] of byVehicle) {
    const rowsSorted = [...rows].sort((a, b) => {
      const da = parseArrivalDatetime(a.arrival)?.getTime() ?? -Infinity;
      const db_ = parseArrivalDatetime(b.arrival)?.getTime() ?? -Infinity;
      return da - db_;
    });
    const depotRows = rowsSorted.filter((r) => isDepotLandmark(r.customer_name));
    const stopRows = rowsSorted.filter((r) => !r.is_passthrough && !r.is_depot && !isDepotLandmark(r.customer_name));

    let routeStart: Date | null = null;
    const departingDepot = depotRows.find((r) => r.departure && r.departure !== "-");
    if (departingDepot) routeStart = parseArrivalDatetime(departingDepot.departure);

    const routeEnd = stopRows.length ? parseArrivalDatetime(stopRows[stopRows.length - 1].departure) : null;

    const routeDuration =
      routeStart && routeEnd && routeEnd.getTime() > routeStart.getTime()
        ? Math.round((routeEnd.getTime() - routeStart.getTime()) / 60000)
        : 0;
    routeMap.set(vkey, { route_duration_minutes: routeDuration, stops: stopRows.length });
  }
  return routeMap;
}

// ---------------------------------------------------------------------------
// Authoritative reference lists (Fleet Database Drivers / Areas / Vehicles)
// ---------------------------------------------------------------------------

async function fetchFleetDriverNames(): Promise<Set<string>> {
  const { data, error } = await supabase.from("drivers").select("name");
  if (error) throw new Error(error.message);
  return new Set((data ?? []).map((d: any) => d.name).filter(Boolean));
}

async function fetchValidAreas(): Promise<AreaRow[]> {
  const { data, error } = await supabase.from("areas").select("name,sector,route_type,vehicle_type");
  if (error) throw new Error(error.message);
  return (data ?? []) as AreaRow[];
}

/** Direct port of _valid_vehicle_keys() - restricts which vehicle
 * identities count as "active"/listed to real, currently-registered
 * Fleet Database vehicles (see that function's docstring in the Python
 * original for why this is scoped to just the active_vehicles KPI rather
 * than a row-level filter on every query). */
async function fetchValidVehicleKeys(): Promise<Set<string>> {
  const { data, error } = await supabase.from("vehicles").select("number");
  if (error) throw new Error(error.message);
  return new Set((data ?? []).map((v: any) => normalizeVehicle(v.number)).filter(Boolean));
}

async function fetchFleetVehicleMap(): Promise<Map<string, { number: string; type: string }>> {
  const { data, error } = await supabase.from("vehicles").select("number,type");
  if (error) throw new Error(error.message);
  const map = new Map<string, { number: string; type: string }>();
  for (const v of data ?? []) {
    const key = normalizeVehicle(v.number);
    if (!key) continue;
    map.set(key, { number: String(v.number || "").trim(), type: String(v.type || "").trim() });
  }
  return map;
}

async function fetchConfigRules(): Promise<ConfigRule[]> {
  const { data, error } = await supabase
    .from("dashboard_config_rules")
    .select("rule_type,value,operator,negate,logic")
    .neq("rule_type", "setting");
  if (error) throw new Error(error.message);
  return (data ?? []) as ConfigRule[];
}

// ---------------------------------------------------------------------------
// Global Filters + Dashboard Configuration exclusions
// (direct ports of apply_global_filters() / apply_dashboard_config_exclusions())
// ---------------------------------------------------------------------------

function csvList(v: string): string[] {
  return v.split(",").map((s) => s.trim()).filter(Boolean);
}

/** Dashboard-only data-quality rule: placeholder/unknown dimensions must never
 * appear in KPI cards, charts, slicers, or dashboard totals. Raw imported data
 * is intentionally preserved; this only excludes it from dashboard calculations. */
function isUnknownDimension(value: unknown): boolean {
  const v = String(value ?? "").trim().toLowerCase();
  return !v || ["unknown", "unclassified", "n/a", "na", "not available", "not available/unknown"].includes(v);
}

function hasValidDashboardClassification(r: SapRow): boolean {
  return !isUnknownDimension(r.facility_type) || !isUnknownDimension(r.division_desc);
}

function wantedFacilityMatch(value: unknown, wantedValues: string[]): boolean {
  const wanted = new Set(wantedValues.map(normalizeDimension));
  return wanted.has(normalizeDimension(value));
}

/** Direct port of apply_global_filters() - Power-BI-style slicers. */
function applyGlobalFilters(rows: SapRow[], f: FilterParams, areas: AreaRow[]): SapRow[] {
  let out = rows.filter((r) => !isUnknownDimension(r.division_desc) && hasValidDashboardClassification(r as SapRow));
  const driverList = csvList(f.drivers);
  if (driverList.length) { const wanted = new Set(driverList.map(normalizeDimension)); out = out.filter((r) => wanted.has(normalizeDimension(r.driver_name))); }
  const areaList = csvList(f.areas);
  if (areaList.length) { const wanted = new Set(areaList.map(normalizeDimension)); out = out.filter((r) => wanted.has(normalizeDimension(r.area))); }
  const divisionList = csvList(f.division);
  if (divisionList.length) { const wanted = new Set(divisionList.map(normalizeDimension)); out = out.filter((r) => wanted.has(normalizeDimension(r.division_desc))); }
  const facilityList = csvList(f.facility_type);
  if (facilityList.length) out = out.filter((r) => wantedFacilityMatch(r.facility_type, facilityList));
  const salesmanList = csvList(f.salesman);
  if (salesmanList.length) { const wanted = new Set(salesmanList.map(normalizeDimension)); out = out.filter((r) => wanted.has(normalizeDimension(r.salesman))); }

  const routeTypes = new Set(csvList(f.route_type));
  const vehicleTypes = new Set(csvList(f.vehicle_type));
  if (routeTypes.size || vehicleTypes.size) {
    const wantedRoutes = new Set([...routeTypes].map(normalizeDimension));
    const wantedVehicles = new Set([...vehicleTypes].map(normalizeDimension));
    const areaRoute = new Map(areas.map(a => [normalizeDimension(a.name), normalizeDimension(a.route_type)]));
    out = out.filter((r) => {
      const vehicleOk = !wantedVehicles.size || wantedVehicles.has(normalizeDimension(r.vehicle_type));
      const routeOk = !wantedRoutes.size || wantedRoutes.has(areaRoute.get(normalizeDimension(r.area)) || "");
      return vehicleOk && routeOk;
    });
  }
  return out;
}

/** One rule -> does `value` match it (before `negate` is applied).
 * Direct port of _condition()/_python_match(). */
function ruleMatches(value: string, rule: ConfigRule): boolean {
  const v = value ?? "";
  const needle = rule.value;
  switch (rule.operator) {
    case "starts_with": return v.startsWith(needle);
    case "ends_with": return v.endsWith(needle);
    case "exact": return v === needle;
    case "regex":
      try { return new RegExp(needle).test(v); } catch { return false; }
    default: return v.includes(needle); // "contains"
  }
}

function ruleMatchesSigned(value: string, rule: ConfigRule): boolean {
  const m = ruleMatches(value, rule);
  return rule.negate ? !m : m;
}

/** One rule_type's worth of rules -> true if the row should be EXCLUDED,
 * combining AND-logic rules together and OR-logic rules together, same as
 * _apply()'s and_rows/or_rows split. */
function typeExcludes(value: string, rulesOfType: ConfigRule[]): boolean {
  if (rulesOfType.length === 0) return false;
  const andRows = rulesOfType.filter((r) => r.logic === "AND");
  const orRows = rulesOfType.filter((r) => r.logic !== "AND");
  const clauses: boolean[] = [];
  if (andRows.length) clauses.push(andRows.every((r) => ruleMatchesSigned(value, r)));
  for (const r of orRows) clauses.push(ruleMatchesSigned(value, r));
  const matchExpr = clauses.some(Boolean);
  return matchExpr;
}

/** Direct port of apply_dashboard_config_exclusions(). */
function applyDashboardConfigExclusions(rows: SapRow[], rules: ConfigRule[], areas: AreaRow[]): SapRow[] {
  const byType = (t: string) => rules.filter((r) => r.rule_type === t);

  let out = rows.filter((r) => !typeExcludes(r.invoice_no, byType("invoice_prefix")));
  out = out.filter((r) => !typeExcludes(r.area, byType("area")));
  out = out.filter((r) => !typeExcludes(r.customer_name, byType("customer")));
  out = out.filter((r) => !typeExcludes(r.facility_type, byType("facility")));
  out = out.filter((r) => !typeExcludes(r.salesman, byType("salesman")));
  out = out.filter((r) => !typeExcludes(r.driver_name, byType("driver")));

  // invoice_range: numeric range on invoice_no, value "START-END", only
  // ever matches rows whose invoice_no is purely numeric.
  const rangeRows = byType("invoice_range");
  if (rangeRows.length) {
    const ranges = rangeRows
      .map((r) => {
        const parts = r.value.split("-");
        if (parts.length !== 2) return null;
        const lo = parseInt(parts[0].trim(), 10);
        const hi = parseInt(parts[1].trim(), 10);
        if (isNaN(lo) || isNaN(hi)) return null;
        return { lo, hi, negate: r.negate };
      })
      .filter((x): x is { lo: number; hi: number; negate: boolean } => x !== null);
    if (ranges.length) {
      out = out.filter((r) => {
        if (!/^\d+$/.test(r.invoice_no || "")) return true; // non-numeric, never matched
        const n = parseInt(r.invoice_no, 10);
        const matches = ranges.map((rg) => {
          const inRange = n >= rg.lo && n <= rg.hi;
          return rg.negate ? !inRange : inRange;
        });
        return !matches.some(Boolean);
      });
    }
  }

  // vehicle_type / route_type: resolved via the current Areas Database,
  // same join apply_global_filters uses.
  const vtRows = byType("vehicle_type");
  const rtRows = byType("route_type");
  if (vtRows.length || rtRows.length) {
    const allAreaNames = new Set(areas.map((a) => a.name));
    const excludedAreaNames = new Set<string>();
    for (const r of vtRows) {
      const hit = new Set(areas.filter((a) => ruleMatches(a.vehicle_type || "", r)).map((a) => a.name));
      if (r.negate) { for (const n of allAreaNames) if (!hit.has(n)) excludedAreaNames.add(n); }
      else { for (const n of hit) excludedAreaNames.add(n); }
    }
    for (const r of rtRows) {
      const hit = new Set(areas.filter((a) => ruleMatches(a.route_type || "", r)).map((a) => a.name));
      if (r.negate) { for (const n of allAreaNames) if (!hit.has(n)) excludedAreaNames.add(n); }
      else { for (const n of hit) excludedAreaNames.add(n); }
    }
    if (excludedAreaNames.size) out = out.filter((r) => !excludedAreaNames.has(r.area));
  }

  return out;
}

// ---------------------------------------------------------------------------
// Shared filtered-rows builder - direct port of build_filtered_sap_query()
// ---------------------------------------------------------------------------

/** Fetches sap_invoice_facts for the date range / single-driver match at
 * the database level (the one thing worth pushing to SQL - see file
 * header), then applies every other rule from build_filtered_sap_query()
 * in the same order the Python did: Global Filters, Dashboard
 * Configuration exclusions, Fleet-Database-authoritative driver
 * restriction, Area-Database-authoritative area restriction. */
async function buildFilteredSapRows(f: FilterParams): Promise<SapRow[]> {
  // Supabase/PostgREST returns at most 1,000 rows per select by default.
  // Dashboard months are much larger than that, so a single select silently
  // under-counted KPIs and charts. Page through the entire filtered range.
  const PAGE = 1000;
  const allRows: SapRow[] = [];
  for (let from = 0; ; from += PAGE) {
    let q = supabase.from("sap_invoice_facts").select("*");
    if (f.start_date) q = q.gte("dispatch_date", f.start_date);
    if (f.end_date) q = q.lte("dispatch_date", f.end_date);
    if (f.driver) q = q.eq("driver_name", f.driver);
    const { data, error } = await q.range(from, from + PAGE - 1);
    if (error) throw new Error(error.message);
    const page = (data ?? []) as SapRow[];
    allRows.push(...page);
    // Large dashboards can contain many pages. Yield to the browser between
    // pages so opening a KPI detail window can paint its loading state and
    // never monopolizes the main thread.
    if (typeof window !== "undefined") await new Promise<void>((resolve) => setTimeout(resolve, 0));
    if (page.length < PAGE) break;
  }
  let rows = allRows;

  const [areas, fleetDriverNames, configRules, fleetVehicles] = await Promise.all([
    fetchValidAreas(),
    fetchFleetDriverNames(),
    fetchConfigRules(),
    fetchFleetVehicleMap(),
  ]);

  // Fleet Database is authoritative for vehicle identity/type whenever the
  // imported SAP vehicle number matches a registered fleet vehicle.
  rows = rows.map((r) => {
    const fleetKey = normalizeVehicle(r.vehicle_num || r.vehicle_key);
    const fleet = fleetVehicles.get(fleetKey);
    return fleet
      ? { ...r, vehicle_num: fleet.number, vehicle_key: fleetKey, vehicle_type: fleet.type || r.vehicle_type }
      : r;
  });

  rows = applyGlobalFilters(rows, f, areas);
  rows = applyDashboardConfigExclusions(rows, configRules, areas);

  // item 1/4/5/6: Fleet Database Drivers table is the single authoritative
  // driver list for every Dashboard driver-level computation - mandatory,
  // not optional (see build_filtered_sap_query()'s own comment).
  if (fleetDriverNames.size) rows = rows.filter((r) => fleetDriverNames.has(r.driver_name));

  // item 8: Area Database is likewise authoritative for area.
  const validAreaNames = new Set(areas.map((a) => a.name));
  if (validAreaNames.size) rows = rows.filter((r) => validAreaNames.has(r.area));

  return rows;
}

// ---------------------------------------------------------------------------
// KPI computation - direct ports of compute_home_kpis_fast() / compute_home_dashboard()
// ---------------------------------------------------------------------------

function computeLeadTimeDays(rows: SapRow[]): number | null {
  const diffs: number[] = [];
  for (const r of rows) {
    if (r.invoice_date && r.dispatch_date) {
      const d1 = new Date(r.invoice_date);
      const d2 = new Date(r.dispatch_date);
      if (!isNaN(d1.getTime()) && !isNaN(d2.getTime())) {
        const diff = Math.round((d2.getTime() - d1.getTime()) / 86400000);
        // item 7: negative lead time (dispatch before invoice date) is a
        // bad/invalid record and must never enter any lead time average.
        if (diff >= 0) diffs.push(diff);
      }
    }
  }
  return diffs.length ? Math.round((diffs.reduce((a, b) => a + b, 0) / diffs.length) * 10) / 10 : null;
}

/** Direct port of compute_home_kpis_fast() - everything except
 * avg_route_hours (which needs the separate, larger landmark_visit_facts
 * fetch - see the Python docstring for why that's split out here too). */
export async function computeHomeKpisFast(f: FilterParams): Promise<Kpis> {
  // Normal path: one compact PostgreSQL RPC. Keep the legacy calculation only
  // when custom Dashboard Configuration exclusion rules are actually active,
  // so those user-defined rules remain exact.
  const rules = await fetchConfigRules();
  if (rules.length === 0) return (await fetchHomeDashboardRpc(f)).kpis;
  const sapRows = await buildFilteredSapRows(f);

  const totalInvoices = sapRows.length;
  const totalBoxes = sapRows.reduce((s, r) => s + (r.boxes || 0), 0);
  const totalNormal = sapRows.reduce((s, r) => s + (r.normal_boxes || 0), 0);
  const totalFreezer = sapRows.reduce((s, r) => s + (r.freezer_boxes || 0), 0);
  const activeDrivers = new Set(sapRows.map((r) => r.driver_name).filter(Boolean)).size;
  const notSuppliedCount = sapRows.filter((r) => r.not_supplied_reason).length;
  const uniqueCustomers = new Set(sapRows.map((r) => r.customer_name).filter(Boolean)).size;

  const validVehicleKeys = await fetchValidVehicleKeys();
  const activeVehicles = new Set(sapRows.filter((r) => r.vehicle_key && validVehicleKeys.has(r.vehicle_key)).map((r) => r.vehicle_key)).size;

  return {
    valid_invoices: totalInvoices,
    total_boxes: totalBoxes,
    freezer_boxes: totalFreezer,
    normal_boxes: totalNormal,
    active_drivers: activeDrivers,
    avg_boxes_per_driver: activeDrivers ? Math.round((totalBoxes / activeDrivers) * 10) / 10 : 0,
    not_supplied: notSuppliedCount,
    avg_lead_time_days: computeLeadTimeDays(sapRows),
    unique_customers: uniqueCustomers,
    avg_route_hours: null, // deliberately omitted - filled in by computeHomeDashboard()
    orders_per_driver: activeDrivers ? Math.round((totalInvoices / activeDrivers) * 10) / 10 : 0,
    active_vehicles: activeVehicles,
  };
}

/** Direct port of compute_home_dashboard() - full Home tab payload: KPIs
 * (including avg_route_hours), Driver Overview table, and the 4 main
 * charts. */
export async function computeHomeDashboard(f: FilterParams): Promise<HomeDashboard> {
  // Fleet is the authoritative source for vehicle identity/type labels. Fetch it
  // before building any chart so every vehicle-type chart uses the current data.
  const fleetVehicles = await fetchFleetVehicleMap();

  // Current/default configuration uses the server-side aggregate path. This
  // removes all SAP pagination and the historical full Landmark-table download
  // from every slicer click. If custom exclusion rules are configured, preserve
  // the legacy exact rule engine as a compatibility fallback.
  const rules = await fetchConfigRules();
  if (rules.length === 0) return fetchHomeDashboardRpc(f);
  const sapRows = await buildFilteredSapRows(f);

  // V1's lmRows isn't independently date-filtered by this same range in
  // the reviewed Python code path either - fetched in full, same as there.
  const { data: lmData, error: lmErr } = await supabase
    .from("landmark_visit_facts")
    .select("vehicle_key,customer_name,arrival,departure,is_passthrough,is_depot");
  if (lmErr) throw new Error(lmErr.message);
  const lmRows = (lmData ?? []) as LandmarkRow[];

  const totalInvoices = sapRows.length;
  const totalBoxes = sapRows.reduce((s, r) => s + (r.boxes || 0), 0);
  const totalNormal = sapRows.reduce((s, r) => s + (r.normal_boxes || 0), 0);
  const totalFreezer = sapRows.reduce((s, r) => s + (r.freezer_boxes || 0), 0);
  const activeDrivers = new Set(sapRows.map((r) => r.driver_name).filter(Boolean)).size;
  const notSuppliedCount = sapRows.filter((r) => r.not_supplied_reason).length;
  const uniqueCustomers = new Set(sapRows.map((r) => r.customer_name).filter(Boolean)).size;
  const validVehicleKeys = await fetchValidVehicleKeys();
  const activeVehicles = new Set(sapRows.filter((r) => r.vehicle_key && validVehicleKeys.has(r.vehicle_key)).map((r) => r.vehicle_key)).size;
  const avgLeadTimeDays = computeLeadTimeDays(sapRows);

  const routeMap = buildLmRouteMap(lmRows);
  const durations = [...routeMap.values()].map((r) => r.route_duration_minutes).filter((m) => m > 0);
  const avgRouteHours = durations.length ? Math.round((durations.reduce((a, b) => a + b, 0) / durations.length / 60) * 10) / 10 : null;

  const kpis: Kpis = {
    valid_invoices: totalInvoices,
    total_boxes: totalBoxes,
    freezer_boxes: totalFreezer,
    normal_boxes: totalNormal,
    active_drivers: activeDrivers,
    avg_boxes_per_driver: activeDrivers ? Math.round((totalBoxes / activeDrivers) * 10) / 10 : 0,
    not_supplied: notSuppliedCount,
    avg_lead_time_days: avgLeadTimeDays,
    unique_customers: uniqueCustomers,
    avg_route_hours: avgRouteHours,
    orders_per_driver: activeDrivers ? Math.round((totalInvoices / activeDrivers) * 10) / 10 : 0,
    active_vehicles: activeVehicles,
  };

  // --- Driver Overview table ---
  const driverPerf = buildDriverPerf(sapRows);
  const nsByDriver = new Map<string, number>();
  for (const r of sapRows) if (r.not_supplied_reason) nsByDriver.set(r.driver_name, (nsByDriver.get(r.driver_name) ?? 0) + 1);

  const driverOverview: DriverRow[] = [...driverPerf.values()]
    .map((d) => ({
      driver_name: d.driver_name, vehicle_num: d.vehicle_num || "-", vehicle_type: d.vehicle_type,
      orders: d.invoices, boxes: d.boxes, freezer: d.freezer, not_supplied: nsByDriver.get(d.driver_name) ?? 0,
    }))
    .sort((a, b) => b.boxes - a.boxes);

  // --- 4 main charts --- (no top-15 cap - see the Python file's own
  // BUGFIX note on why that cap was removed)
  const topDrivers = [...driverPerf.values()].sort((a, b) => b.boxes - a.boxes);
  const driverBoxesChart = { labels: topDrivers.map((d) => d.driver_name), values: topDrivers.map((d) => d.boxes) };

  // Every chart dimension is dynamic data, never a fixed enum. Group values
  // case/spacing-insensitively, while choosing one canonical display label.
  const facilityCounts = new Map<string, { value: number; labels: string[] }>();
  for (const r of sapRows) {
    const raw = String(r.facility_type || "").trim();
    if (!raw) continue;
    const key = normalizeDimension(raw);
    const x = facilityCounts.get(key) || { value: 0, labels: [] };
    x.value += 1; x.labels.push(raw); facilityCounts.set(key, x);
  }
  const facilityKeys = [...facilityCounts.keys()].sort((a,b) => a.localeCompare(b));
  const facilityChart = {
    labels: facilityKeys.map(k => canonicalLabel(facilityCounts.get(k)?.labels || [k])),
    values: facilityKeys.map(k => facilityCounts.get(k)?.value || 0),
  };

  const vantypeNormal = new Map<string, number>();
  const vantypeFreezer = new Map<string, number>();
  const vantypeLabels = new Map<string, string[]>();
  for (const r of sapRows) {
    const raw = String(r.vehicle_type || "").trim();
    if (!raw) continue;
    const key = normalizeDimension(raw);
    vantypeNormal.set(key, (vantypeNormal.get(key) ?? 0) + (r.normal_boxes || 0));
    vantypeFreezer.set(key, (vantypeFreezer.get(key) ?? 0) + (r.freezer_boxes || 0));
    const labels = vantypeLabels.get(key) || []; labels.push(raw); vantypeLabels.set(key, labels);
  }
  const fleetTypeByKey = new Map<string, string>();
  for (const v of fleetVehicles.values()) {
    const t = String(v.type || "").trim();
    if (t) fleetTypeByKey.set(normalizeDimension(t), t);
  }
  const vanKeys = [...new Set([...vantypeNormal.keys(), ...vantypeFreezer.keys()])].sort();
  const vanTypes = vanKeys.map(k => fleetTypeByKey.get(k) || canonicalLabel(vantypeLabels.get(k) || [k]));
  const vantypeChart = {
    labels: vanTypes,
    normal: vanKeys.map((v) => vantypeNormal.get(v) ?? 0),
    freezer: vanKeys.map((v) => vantypeFreezer.get(v) ?? 0),
  };

  const returnsChart = { delivered: totalInvoices, not_supplied: notSuppliedCount };

  return { kpis, driver_overview: driverOverview, charts: { driver_boxes: driverBoxesChart, facility: facilityChart, vantype: vantypeChart, returns: returnsChart } };
}

const DETAIL_ROW_LIMIT = 200;

/** Fast KPI detail path: the first 200 rows come directly from PostgreSQL.
 * The old implementation fetched the entire month before returning those 200
 * rows, which is exactly why a small popup could take minutes. */
export async function getHomeDetailRows(metric: string, f: FilterParams, offset = 0, search = ""): Promise<HomeDetailResponse> {
  const { getFederatedSupabaseClients } = await import("@/lib/supabase");
  const filters = homeFilterJson(f);
  const parts = await Promise.all(getFederatedSupabaseClients().map(async (client: any) => {
    const { data, error } = await client.rpc("dispatchops_dashboard_home_detail", {
      p_start: f.start_date || null, p_end: f.end_date || null, p_metric: metric,
      p_filters: filters, p_limit: DETAIL_ROW_LIMIT, p_offset: offset, p_search: search || ""
    });
    if (error) throw new Error(error.message);
    return data || { metric, columns: [], rows: [], truncated: false, total_matching: 0 };
  }));
  const rows = parts.flatMap((p: any) => Array.isArray(p.rows) ? p.rows : []);
  // Federated projects can each have up to 200 rows. Keep the UI batch bounded
  // to 200 while preserving the global newest-first order.
  rows.sort((a: any, b: any) => String(b.dispatch_date || "").localeCompare(String(a.dispatch_date || "")));
  const limited = rows.slice(0, DETAIL_ROW_LIMIT);
  const total = parts.reduce((n: number, p: any) => n + Number(p.total_matching || 0), 0);
  return {
    metric,
    columns: parts.find((p: any) => Array.isArray(p.columns) && p.columns.length)?.columns || [],
    rows: limited,
    truncated: total > offset + limited.length,
    total_matching: total,
  };
}

// ---------------------------------------------------------------------------
// Filter Slicers - direct port of the /dashboard/filter-options route
// ---------------------------------------------------------------------------

export interface FilterOptions {
  divisions: string[];
  facility_types: string[];
  salesmen: string[];
  areas: string[];
  drivers: string[];
}

export interface DashboardFilterMeta extends FilterOptions {
  vehicle_types: string[];
  route_types: string[];
}

/**
 * Fast dashboard slicer metadata.
 *
 * The old implementation paged through every SAP invoice row before the
 * dashboard could populate its dropdowns. That made the dashboard feel stuck
 * even though the actual slicer values are just distinct dimension values.
 * The v21 RPC returns all slicer lists in one small response and also makes
 * Fleet Database vehicle types authoritative.
 */
export async function getDashboardDriverOptionsDynamic(
  startDate?: string,
  endDate?: string,
  filters: { areas?: string[]; division?: string[]; facility_type?: string[]; salesman?: string[]; vehicle_type?: string[] } = {},
): Promise<{ drivers: string[]; driver_names: Array<{ code: string; name: string }> }> {
  const payload = {
    areas: filters.areas || [], division: filters.division || [], facility_type: filters.facility_type || [],
    salesman: filters.salesman || [], vehicle_type: filters.vehicle_type || [],
  };
  const cacheKey = dashboardDriverOptionsCacheKey(startDate, endDate, payload);
  const cached = readJsonCache<{ drivers: string[]; driver_names: Array<{ code: string; name: string }> }>(cacheKey, DRIVER_OPTIONS_CACHE_MS);
  if (cached) {
    // Revalidate in the background; callers can paint from cache immediately.
    void getDashboardDriverOptionsDynamicFresh(startDate, endDate, payload, cacheKey).catch(() => {});
    return cached;
  }
  return getDashboardDriverOptionsDynamicFresh(startDate, endDate, payload, cacheKey);
}

async function getDashboardDriverOptionsDynamicFresh(
  startDate: string | undefined,
  endDate: string | undefined,
  payload: Record<string, unknown>,
  cacheKey: string,
): Promise<{ drivers: string[]; driver_names: Array<{ code: string; name: string }> }> {
  const clients = getFederatedSupabaseClients();
  const results = await Promise.all(clients.map(async (client: any) => {
    try {
      const result = await client.rpc("dispatchops_dashboard_driver_options_dynamic", {
        p_start: startDate || null, p_end: endDate || null, p_filters: payload,
      });
      if (result.error) return null;
      return result.data || {};
    } catch { return null; }
  }));
  const driverSet = new Set<string>();
  const nameMap = new Map<string, { code: string; name: string }>();
  for (const value of results) {
    for (const code of Array.isArray(value?.drivers) ? value.drivers : []) {
      const v = String(code).trim(); if (v) driverSet.add(v);
    }
    for (const row of Array.isArray(value?.driver_names) ? value.driver_names : []) {
      const code = String(row?.code || '').trim(); const name = String(row?.name || '').trim();
      if (code) nameMap.set(code.toLowerCase(), { code, name });
    }
  }
  const out = {
    drivers: Array.from(driverSet).sort(),
    driver_names: Array.from(nameMap.values()).sort((a, b) => a.name.localeCompare(b.name) || a.code.localeCompare(b.code)),
  };
  // Never poison the local cache with an empty response caused by a missing
  // RPC, transient auth/network failure, or a project that does not expose
  // the dashboard function yet. An empty cache makes the Excel-like fast path
  // look authoritative and hides the real data on the next render.
  if (hasMeaningfulDriverOptions(out)) writeJsonCache(cacheKey, out);
  else {
    const meta = getCachedDashboardFilterMeta(startDate, endDate) || readLegacyFilterMetaCache();
    if (meta?.drivers?.length) return { drivers: meta.drivers, driver_names: [] };
  }
  return out;
}

export async function getDashboardFilterMeta(startDate?: string, endDate?: string): Promise<DashboardFilterMeta> {
  const cacheKey = dashboardFilterMetaCacheKey(startDate, endDate);
  const cached = readJsonCache<DashboardFilterMeta>(cacheKey, FILTER_META_CACHE_MS);
  if (cached) {
    void getDashboardFilterMetaFresh(startDate, endDate, cacheKey).catch(() => {});
    return cached;
  }
  return getDashboardFilterMetaFresh(startDate, endDate, cacheKey);
}

async function getDashboardFilterMetaFresh(startDate?: string, endDate?: string, cacheKey = dashboardFilterMetaCacheKey(startDate, endDate)): Promise<DashboardFilterMeta> {
  const clients = getFederatedSupabaseClients();
  const results = await Promise.all(clients.map(async (client: any) => {
    try {
      const result = await client.rpc("dispatchops_dashboard_filter_meta_v2", { p_start: startDate || null, p_end: endDate || null });
      if (result.error) return { data: null, error: result.error };
      return { data: result.data || {}, error: null };
    } catch (error) { return { data: null, error }; }
  }));
  const successful = results.filter((r: any) => !r.error && r.data && hasMeaningfulFilterMeta(r.data));
  if (!successful.length) {
    const stale = readJsonCache<DashboardFilterMeta>(cacheKey, 24 * 60 * 60_000) || readLegacyFilterMetaCache();
    if (stale) return stale;
    const error: any = results.find((r: any) => r.error)?.error;
    throw new Error(error?.message || "Unable to load Dashboard filter metadata.");
  }
  const merged: DashboardFilterMeta = { divisions: [], facility_types: [], salesmen: [], areas: [], drivers: [], vehicle_types: [], route_types: [] };
  for (const result of successful) {
    const v = result.data || {};
    for (const key of Object.keys(merged) as (keyof DashboardFilterMeta)[]) {
      const current = merged[key] as string[];
      const incoming = Array.isArray(v[key]) ? v[key] : [];
      (merged as any)[key] = [...new Set([...current, ...incoming].map(String).map(x => x.trim()).filter(Boolean))].sort();
    }
  }
  if (hasMeaningfulFilterMeta(merged)) {
    writeJsonCache(cacheKey, merged);
    if (!startDate && !endDate) writeJsonCache(FILTER_META_CACHE_PREFIX + "default", merged);
  } else {
    const stale = readLegacyFilterMetaCache();
    if (stale) return stale;
  }
  return merged;
}

/** Backwards-compatible helper used by non-dashboard callers. */
export async function getFilterOptions(): Promise<FilterOptions> {
  const cached = getCachedDashboardFilterMeta();
  if (cached) {
    // Return the cached list immediately. Dashboard refreshes update it in the
    // background, so opening the Dashboard never waits for metadata.
    void getDashboardFilterMeta().catch(() => {});
    return cached;
  }
  const meta = await getDashboardFilterMeta();
  return {
    divisions: meta.divisions,
    facility_types: meta.facility_types,
    salesmen: meta.salesmen,
    areas: meta.areas,
    drivers: meta.drivers,
  };
}

export function getCachedDashboardFilterMetaLegacy(): DashboardFilterMeta | null {
  return getCachedDashboardFilterMeta();
}
