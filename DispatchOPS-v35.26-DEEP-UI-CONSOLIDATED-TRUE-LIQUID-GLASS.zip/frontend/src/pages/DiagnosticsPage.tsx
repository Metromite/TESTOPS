import DiagnosticsTab from "./DiagnosticsTab";

/**
 * NAV REDESIGN: this used to be one of Dashboard's internal tabs. The
 * Dashboard page now only shows Overview/Analytics, so this moved to its
 * own route (linked from the Admin nav group) - same component, same
 * data, same behavior, just reached via a different nav path.
 */
export default function DiagnosticsPage() {
  return (
    <div className="page diagnostics-page">
      <h2>Diagnostics</h2>
      <p style={{ color: "var(--muted)", fontSize: 13, marginTop: -8, marginBottom: 16 }}>
        Data load, matching, and validation health checks for the current import.
      </p>
      <DiagnosticsTab />
    </div>
  );
}
